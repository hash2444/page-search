// Page Search - made by dev:#2444 - https://github.com/hash2444/page-search
// Runs on the web page itself. Searches text, highlights matches and jumps to them.
// Wird bei jedem Öffnen des Popups neu injiziert -> daher der Wiederholungs-Schutz.
(() => {
  if (window.__seitenSuche) return; // schon aktiv, Zustand behalten

  const ALL = "ss-all";
  const CUR = "ss-current";

  const supportsHighlight =
    "highlights" in CSS && typeof Highlight !== "undefined";

  const state = { ranges: [], index: -1, query: "" };
  window.__seitenSuche = state;

  // Farb-Regeln für die Markierungen einmalig einfügen.
  if (supportsHighlight && !document.getElementById("ss-style")) {
    const style = document.createElement("style");
    style.id = "ss-style";
    style.textContent =
      `::highlight(${ALL}){background-color:#f9f002;color:#000;}` +
      `::highlight(${CUR}){background-color:#00f0ff;color:#000;` +
      `text-shadow:0 0 8px rgba(0,240,255,.9);}`;
    document.documentElement.appendChild(style);
  }

  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  const visCache = new Map();
  function isVisible(el) {
    if (visCache.has(el)) return visCache.get(el);
    // Elemente in display:none haben keine ClientRects (deckt auch Vorfahren ab).
    const res =
      el.getClientRects().length > 0 &&
      getComputedStyle(el).visibility !== "hidden";
    visCache.set(el, res);
    return res;
  }

  function collectTextNodes() {
    visCache.clear();
    const skip = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA"]);
    const nodes = [];
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const v = node.nodeValue;
          if (!v || !v.trim()) return NodeFilter.FILTER_REJECT;
          const parent = node.parentElement;
          if (!parent || skip.has(parent.tagName))
            return NodeFilter.FILTER_REJECT;
          if (!isVisible(parent)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    return nodes;
  }

  // Alle Textknoten zu einem String zusammenkleben + Start-Position merken.
  function buildIndex(nodes) {
    let text = "";
    const map = [];
    for (const node of nodes) {
      map.push({ node, start: text.length });
      text += node.nodeValue;
    }
    return { text, map };
  }

  // Globalen Zeichen-Index -> konkreter Textknoten + Offset (binäre Suche).
  function locate(map, g) {
    let lo = 0,
      hi = map.length - 1,
      ans = 0;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (map[mid].start <= g) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    const entry = map[ans];
    return { node: entry.node, offset: g - entry.start };
  }

  function makeRange(map, gStart, gEnd) {
    const a = locate(map, gStart);
    const b = locate(map, gEnd);
    try {
      const range = document.createRange();
      range.setStart(a.node, a.offset);
      range.setEnd(b.node, b.offset);
      return range;
    } catch (e) {
      return null;
    }
  }

  function applyHighlights() {
    if (!supportsHighlight) return;
    CSS.highlights.delete(ALL);
    CSS.highlights.delete(CUR);
    if (!state.ranges.length) return;
    CSS.highlights.set(ALL, new Highlight(...state.ranges));
    if (state.index >= 0) {
      const cur = new Highlight(state.ranges[state.index]);
      cur.priority = 1; // the current match outshines the yellow highlight
      CSS.highlights.set(CUR, cur);
    }
  }

  function clear() {
    state.ranges = [];
    state.index = -1;
    state.query = "";
    if (supportsHighlight) {
      CSS.highlights.delete(ALL);
      CSS.highlights.delete(CUR);
    }
  }

  function search(query, opts) {
    clear();
    state.query = query || "";
    if (!query) return { count: 0, index: 0, supported: supportsHighlight };

    const { text, map } = buildIndex(collectTextNodes());
    let re;
    try {
      let pattern = escapeRegExp(query);
      if (opts && opts.wholeWord) pattern = `\\b${pattern}\\b`;
      re = new RegExp(pattern, opts && opts.caseSensitive ? "g" : "gi");
    } catch (e) {
      return { count: 0, index: 0, supported: supportsHighlight };
    }

    const ranges = [];
    let m;
    while ((m = re.exec(text))) {
      if (m.index === re.lastIndex) {
        re.lastIndex++;
        continue; // Schutz vor Endlosschleife bei Länge 0
      }
      const range = makeRange(map, m.index, m.index + m[0].length);
      if (range) ranges.push(range);
      if (ranges.length > 10000) break; // Sicherheitslimit
    }

    state.ranges = ranges;
    state.index = ranges.length ? 0 : -1;
    applyHighlights();
    if (state.index >= 0) scrollToCurrent();
    return {
      count: ranges.length,
      index: state.index,
      supported: supportsHighlight,
    };
  }

  function scrollToCurrent() {
    const range = state.ranges[state.index];
    if (!range) return;
    const rect = range.getBoundingClientRect();
    const y = rect.top + window.scrollY - window.innerHeight / 2;
    window.scrollTo({ top: Math.max(0, y), behavior: "smooth" });
  }

  function goTo(nextIndex) {
    if (!state.ranges.length) return { count: 0, index: 0 };
    const len = state.ranges.length;
    state.index = ((nextIndex % len) + len) % len; // sauberes Umlaufen
    applyHighlights();
    scrollToCurrent();
    return { count: len, index: state.index };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.type) {
      case "ping":
        sendResponse({ ok: true, supported: supportsHighlight });
        break;
      case "search":
        sendResponse(search(msg.query, msg.opts));
        break;
      case "next":
        sendResponse(goTo(state.index + 1));
        break;
      case "prev":
        sendResponse(goTo(state.index - 1));
        break;
      case "clear":
        clear();
        sendResponse({ count: 0, index: 0 });
        break;
      default:
        sendResponse(null);
    }
    return true;
  });
})();
