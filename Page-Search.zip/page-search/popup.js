// Page Search - made by dev:#2444 - https://github.com/hash2444/page-search
const input = document.getElementById("q");
const counter = document.getElementById("counter");
const statusEl = document.getElementById("status");
const caseChk = document.getElementById("case");
const wordChk = document.getElementById("word");

let tabId = null;
let ready = false;
let debounce;

function send(msg) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, msg, (res) => {
      void chrome.runtime.lastError; // Fehler bewusst schlucken
      resolve(res);
    });
  });
}

function showStatus(text) {
  statusEl.textContent = text || "";
  statusEl.classList.toggle("show", !!text);
}

function updateCounter(res) {
  counter.classList.remove("has-hits", "no-hits");
  if (!res || res.count === 0) {
    counter.textContent = input.value ? "0/0" : "";
    if (input.value) counter.classList.add("no-hits");
  } else {
    counter.textContent = `${res.index + 1}/${res.count}`;
    counter.classList.add("has-hits");
  }
  // Pop-Animation neu anstoßen
  counter.classList.remove("pop");
  void counter.offsetWidth; // Reflow erzwingen, damit die Animation neu startet
  counter.classList.add("pop");
}

async function runSearch() {
  if (!ready) return;
  const query = input.value;
  const opts = { caseSensitive: caseChk.checked, wholeWord: wordChk.checked };
  const res = await send({ type: "search", query, opts });
  updateCounter(res);
  chrome.storage.local.set({
    query,
    caseSensitive: caseChk.checked,
    wholeWord: wordChk.checked,
  });
}

async function nav(dir) {
  if (!ready) return;
  const res = await send({ type: dir });
  updateCounter(res);
}

input.addEventListener("input", () => {
  clearTimeout(debounce);
  debounce = setTimeout(runSearch, 180);
});

input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    if (counter.textContent && counter.textContent !== "0/0") {
      nav(e.shiftKey ? "prev" : "next");
    } else {
      runSearch();
    }
  }
});

caseChk.addEventListener("change", runSearch);
wordChk.addEventListener("change", runSearch);
document.getElementById("next").addEventListener("click", () => nav("next"));
document.getElementById("prev").addEventListener("click", () => nav("prev"));

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) {
    showStatus("No active tab.");
    input.disabled = true;
    return;
  }
  tabId = tab.id;

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"],
    });
  } catch (e) {
    showStatus("Not available on this page (for example the start page or the store).");
    input.disabled = true;
    return;
  }

  const pong = await send({ type: "ping" });
  if (!pong) {
    showStatus("The page does not respond - please reload it.");
    input.disabled = true;
    return;
  }
  if (!pong.supported) {
    showStatus("Your browser is too old for coloured highlighting.");
  }

  ready = true;

  // Letzte Sucheinstellungen wiederherstellen.
  const saved = await chrome.storage.local.get([
    "query",
    "caseSensitive",
    "wholeWord",
  ]);
  caseChk.checked = !!saved.caseSensitive;
  wordChk.checked = !!saved.wholeWord;
  if (saved.query) {
    input.value = saved.query;
    runSearch();
  }

  input.focus();
  input.select();
}

init();
